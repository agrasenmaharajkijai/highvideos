const correctUserId = "user3";
const correctPassword = "user@3";

function checkLogin() {
    const userId = document.getElementById("userId").value;
    const password = document.getElementById("password").value;

    if (userId === correctUserId && password === correctPassword) {
        document.getElementById("loginContainer").style.display = "none";
        document.getElementById("videoContainer").style.display = "block";
    } else {
        alert("Invalid User ID or Password. Please try again.");
    }
}

function setVideoQuality(quality) {
    const videoPlayer = document.getElementById('videoPlayer');
    const videoSource = document.getElementById('videoSource');

    if (quality === 'low') {
        videoSource.src = 'website_video.mp4#t=0.1';
    } else if (quality === 'medium') {
        videoSource.src = 'website_video.mp4#t=0.5';
    } else if (quality === 'high') {
        videoSource.src = 'website_video.mp4';
    }
    videoPlayer.load();
}